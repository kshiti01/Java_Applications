/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Date;

/**
 *
 * @author kshit
 */
public class Encounter {
    
    VitalSigns vitalsigns;
    private Date lastVisitDate;
    
     public Encounter(){
        vitalsigns =new VitalSigns();
    }
     
   
    public Date getLastVisitDate() {
        return lastVisitDate;
    }

    public VitalSigns getVitalsigns() {
        return vitalsigns;
    }

    public void setVitalsigns(VitalSigns vitalsigns) {
        this.vitalsigns = vitalsigns;
    }


    

    
    
   
}
